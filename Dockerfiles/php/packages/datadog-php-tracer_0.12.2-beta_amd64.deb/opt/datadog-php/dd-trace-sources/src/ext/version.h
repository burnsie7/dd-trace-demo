#ifndef PHP_DDTRACE_VERSION
#define PHP_DDTRACE_VERSION "0.12.2-beta"
#endif
