# Datadog PHP integration

This page has been moved to the [PHP-instrumentation documentation](https://docs.datadoghq.com/tracing/languages/php/).
